# RescueNet (local demo)

A React + Vite frontend and Flask + SQLite backend. All responders/incidents are simulated. This prototype does not contact emergency services.

## Windows quick start

1. Extract this ZIP. Open the extracted `rescuenet` folder in VS Code (the folder containing `START_BACKEND.bat`, `START_FRONTEND.bat`, `backend`, and `frontend`).
2. Create `backend/.env` by copying `backend/.env.example`. Put your own Gemini key on the `GEMINI_API_KEY=` line. Never share or commit `.env`.
3. Double-click `START_BACKEND.bat` (or run it from a terminal). Keep that window open.
4. Double-click `START_FRONTEND.bat` (or run it from a second terminal). Keep that window open.
5. Open the Vite URL shown in the frontend terminal, normally http://localhost:5173.

If using terminals manually from the project root:
- Backend: `cd backend`, `python -m pip install -r requirements.txt`, `python app.py`
- Frontend: in a second terminal, `cd frontend`, `npm install`, `npm run dev`

The Flask API health endpoint is http://127.0.0.1:5000/api/health. The API root at http://127.0.0.1:5000/ returns a small status response; the website itself is served by Vite.

## Requirements
- Python 3.10+ and Node.js LTS installed and available on PATH.
- Gemini key from https://aistudio.google.com/api-keys (optional; rule-based fallback remains available without it).

## Safety
Demo only. Do not rely on this prototype for real emergencies. In an actual emergency, contact official local emergency services.
