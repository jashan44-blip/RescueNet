export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: {
    colors: { navy: { 900: '#070e22', 800: '#0b1530', 700: '#13204a', 600: '#1b2d63' } },
    fontFamily: { display: ['"Barlow Condensed"', 'sans-serif'], sans: ['"Public Sans"', 'system-ui', 'sans-serif'] } } } }
