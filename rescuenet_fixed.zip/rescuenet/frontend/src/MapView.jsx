import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { tierColor } from './ui'

const CENTER = [30.4836, 76.594]
const dot = (color, sel) => L.divIcon({ className: '', iconSize: [26, 26], iconAnchor: [13, 13], html: `<div class="mk ${sel ? 'mk-sel' : ''}" style="background:${color}"></div>` })
const unit = L.divIcon({ className: '', iconSize: [20, 20], iconAnchor: [10, 10], html: '<div class="mu"></div>' })

export default function MapView({ incidents = [], responders = [], selectedId, onSelect, routeFrom, pick, onPick }) {
  const el = useRef(), map = useRef(), layer = useRef(), routeLayer = useRef(), pickMk = useRef()
  const pickRef = useRef(onPick); pickRef.current = onPick
  const selRef = useRef(onSelect); selRef.current = onSelect

  useEffect(() => {
    map.current = L.map(el.current).setView(pick?.lat ? [pick.lat, pick.lng] : CENTER, 13)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap contributors', maxZoom: 19 }).addTo(map.current)
    layer.current = L.layerGroup().addTo(map.current)
    routeLayer.current = L.layerGroup().addTo(map.current)
    if (onPick) map.current.on('click', (e) => pickRef.current(e.latlng.lat, e.latlng.lng))
    return () => map.current.remove()
  }, [])

  useEffect(() => {
    layer.current.clearLayers()
    incidents.forEach((i) => L.marker([i.lat, i.lng], { icon: dot(tierColor(i), i.id === selectedId), zIndexOffset: i.id === selectedId ? 1000 : 0 })
      .bindTooltip(`#${i.id} ${i.type}, priority ${i.score}`).on('click', () => selRef.current?.(i.id)).addTo(layer.current))
    responders.forEach((r) => L.marker([r.lat, r.lng], { icon: unit }).bindTooltip(`${r.name} (simulated), ${r.status}`).addTo(layer.current))
  }, [incidents, responders, selectedId])

  useEffect(() => {
    if (!onPick) return
    pickMk.current?.remove()
    if (pick?.lat) pickMk.current = L.marker([pick.lat, pick.lng]).addTo(map.current)
  }, [pick?.lat, pick?.lng])

  const sel = incidents.find((i) => i.id === selectedId)
  useEffect(() => {
    routeLayer.current.clearLayers()
    if (!sel || !routeFrom || sel.status === 'Resolved') return
    const a = [routeFrom[0], routeFrom[1]], b = [sel.lat, sel.lng]
    const line = L.polyline([a, b], { color: '#0ea5e9', weight: 3, dashArray: '6 8' }).addTo(routeLayer.current)
    map.current.fitBounds(L.latLngBounds([a, b]).pad(0.4))
    let dead = false
    fetch(`https://router.project-osrm.org/route/v1/driving/${a[1]},${a[0]};${b[1]},${b[0]}?overview=full&geometries=geojson`)
      .then((r) => r.json()).then((j) => {
        const g = j.routes?.[0]?.geometry?.coordinates
        if (!dead && g) { line.setLatLngs(g.map(([x, y]) => [y, x])); line.setStyle({ dashArray: null, weight: 4 }) }
      }).catch(() => {})
    return () => { dead = true }
  }, [selectedId, routeFrom?.[0], routeFrom?.[1], sel?.status])

  return <div ref={el} className="h-full w-full rounded-xl" style={{ zIndex: 0 }} />
}
