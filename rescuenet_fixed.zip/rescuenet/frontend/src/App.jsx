import { useCallback, useEffect, useState } from 'react'
import { api } from './api'
import MapView from './MapView'
import Detail from './Detail'
import { TIER, Pill, tierColor, inkOf, ago } from './ui'

const NAV = ['Dashboard', 'Report Emergency', 'Incidents', 'Responders', 'Settings']
const TYPES = ['Accident', 'Fire', 'Medical', 'Flood', 'Other']
const C = [30.4836, 76.594]
const blank = { type: 'Accident', description: '', address: '', lat: null, lng: null, people: 1, trapped: false, critical: false }
const SAMPLE = 'A car left the road and hit a tree near the canal bridge on the bypass. The driver is still inside and looks hurt.'

function Queue({ items, selectedId, onSelect, empty }) {
  if (!items.length) return <p className="p-6 text-center text-sm text-slate-500">{empty}</p>
  return (
    <ul className="space-y-2">{items.map((i) => (
      <li key={i.id}>
        <button onClick={() => onSelect(i.id)} style={{ borderLeft: `6px solid ${tierColor(i)}` }}
          className={`flex w-full items-center gap-3 rounded-lg border p-3 text-left transition ${i.id === selectedId ? 'border-slate-700 bg-slate-100' : 'border-slate-200 bg-white hover:bg-slate-50'}`}>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5 text-sm"><b>#{i.id} {i.type}</b>
              <Pill c={inkOf(i)}>{i.status === 'Resolved' ? 'Resolved' : i.tier}</Pill>{i.trapped && <Pill c="#b91c1c">Trapped</Pill>}</div>
            <p className="truncate text-sm text-slate-600">{i.description.split('\n')[0]}</p>
            <p className="text-xs text-slate-500">{i.people} affected, {i.status}, {ago(i.created_at)}</p>
          </div>
          <span key={i.score} className="pop font-display text-4xl font-semibold" style={{ color: inkOf(i) }}>{i.score}</span>
        </button>
      </li>))}
    </ul>
  )
}

function Report({ onDone, notify }) {
  const [f, setF] = useState(blank), [ai, setAi] = useState(null), [busy, setBusy] = useState(false)
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }))
  const analyze = async () => {
    setBusy(true)
    try { setAi(await api.classify({ text: f.description, type: f.type })) } catch (e) { notify(e.message, 'err') }
    setBusy(false)
  }
  const submit = async () => {
    setBusy(true)
    try { const i = await api.create({ ...f, people: +f.people, ai }); setF(blank); setAi(null); onDone(i) } catch (e) { notify(e.message, 'err') }
    setBusy(false)
  }
  const locate = () => navigator.geolocation?.getCurrentPosition((p) => setF((s) => ({ ...s, lat: p.coords.latitude, lng: p.coords.longitude })), () => notify('Location unavailable. Click the map instead.', 'err'))
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <form className="panel space-y-4" onSubmit={(e) => { e.preventDefault(); submit() }}>
        <div><span className="mb-1 block text-sm font-medium">Emergency type</span>
          <div className="flex flex-wrap gap-2">{TYPES.map((t) => (
            <button type="button" key={t} onClick={() => set('type', t)} className={`btn ${f.type === t ? 'btn-primary' : 'btn-ghost'}`}>{t}</button>))}</div></div>
        <div><label className="mb-1 block text-sm font-medium" htmlFor="d">What happened?</label>
          <textarea id="d" className="input" rows={4} required value={f.description} onChange={(e) => { set('description', e.target.value); setAi(null) }} placeholder="Describe the incident, who is affected and any danger." />
          <button type="button" className="mt-1 text-xs text-sky-700 underline" onClick={() => set('description', SAMPLE)}>Fill with demo report</button></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="mb-1 block text-sm font-medium" htmlFor="p">People affected</label>
            <input id="p" type="number" min="0" className="input" value={f.people} onChange={(e) => set('people', e.target.value)} /></div>
          <div><label className="mb-1 block text-sm font-medium" htmlFor="a">Location or landmark</label>
            <input id="a" className="input" value={f.address} onChange={(e) => set('address', e.target.value)} /></div>
        </div>
        <div className="flex flex-wrap gap-5 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" checked={f.trapped} onChange={(e) => set('trapped', e.target.checked)} />Someone is trapped</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={f.critical} onChange={(e) => set('critical', e.target.checked)} />Someone is critically injured</label>
        </div>
        <p className="text-xs text-slate-500">{f.lat ? `Pin set at ${(+f.lat).toFixed(4)}, ${(+f.lng).toFixed(4)}` : 'Click the map to drop a pin, or use your location. Without a pin the simulated city centre is used.'}</p>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-ghost" onClick={locate}>Use my location</button>
          <button type="button" className="btn btn-ghost" disabled={busy || !f.description.trim()} onClick={analyze}>Analyze with AI</button>
          <button className="btn btn-red" disabled={busy || !f.description.trim()}>Submit report</button>
        </div>
        <p className="text-xs text-slate-500">Submitting never waits for the AI. Simulated report only; no real emergency service is contacted.</p>
      </form>
      <div className="space-y-4">
        <div className="panel h-72 overflow-hidden !p-0"><MapView pick={f} onPick={(lat, lng) => setF((s) => ({ ...s, lat, lng }))} /></div>
        {ai && (
          <div className="panel space-y-1 text-sm">
            <p className="font-semibold">{ai.source === 'gemini' ? 'Gemini classification' : 'Rule-based fallback (Gemini unavailable)'}</p>
            <p>Category <b>{ai.category}</b>, severity <b>{ai.severity}</b>, about <b>{ai.people}</b> affected, trapped: <b>{ai.trapped ? 'possibly' : 'no sign'}</b></p>
            <p>Recommended action: {ai.action}</p>
            <button type="button" className="btn btn-ghost mt-1" onClick={() => setF((s) => ({ ...s, type: ai.category, people: Math.max(+s.people, ai.people), trapped: s.trapped || ai.trapped }))}>Apply to form</button>
          </div>)}
      </div>
    </div>
  )
}

function IncidentsPage({ incidents, selectedId, setSelectedId, ...rest }) {
  const [q, setQ] = useState({ status: '', type: '', tier: '', text: '' })
  const s = (k) => (e) => setQ((p) => ({ ...p, [k]: e.target.value }))
  const items = incidents.filter((i) => (!q.status || i.status === q.status) && (!q.type || i.type === q.type) && (!q.tier || i.tier === q.tier) && (!q.text || i.description.toLowerCase().includes(q.text.toLowerCase())))
  const sel = incidents.find((i) => i.id === selectedId)
  return (
    <div className="space-y-4">
      <div className="panel grid gap-2 sm:grid-cols-4">
        <select className="input" value={q.status} onChange={s('status')} aria-label="Status"><option value="">All statuses</option>{['Reported', 'Assigned', 'In progress', 'Resolved'].map((x) => <option key={x}>{x}</option>)}</select>
        <select className="input" value={q.type} onChange={s('type')} aria-label="Type"><option value="">All types</option>{TYPES.map((x) => <option key={x}>{x}</option>)}</select>
        <select className="input" value={q.tier} onChange={s('tier')} aria-label="Priority"><option value="">All priorities</option>{['Critical', 'High', 'Medium', 'Low'].map((x) => <option key={x}>{x}</option>)}</select>
        <input className="input" placeholder="Search description" value={q.text} onChange={s('text')} />
      </div>
      <div className="grid gap-4 xl:grid-cols-5">
        <div className="panel xl:col-span-2"><Queue items={items} selectedId={selectedId} onSelect={setSelectedId} empty="No incidents match these filters." /></div>
        <div className="panel xl:col-span-3"><Detail inc={sel} {...rest} /></div>
      </div>
    </div>
  )
}

export default function App() {
  const [page, setPage] = useState('Dashboard')
  const [incidents, setIncidents] = useState([])
  const [responders, setResponders] = useState([])
  const [health, setHealth] = useState({})
  const [selectedId, setSelectedId] = useState(null)
  const [routeFrom, setRouteFrom] = useState(null)
  const [toast, setToast] = useState(null)
  const [offline, setOffline] = useState(false)

  const notify = (msg, kind = 'ok') => { setToast({ msg, kind }); setTimeout(() => setToast(null), 3500) }
  const refresh = useCallback(async () => {
    try { const [i, r] = await Promise.all([api.incidents(), api.responders()]); setIncidents(i); setResponders(r); setOffline(false) } catch { setOffline(true) }
  }, [])
  useEffect(() => { refresh(); api.health().then(setHealth).catch(() => {}); const t = setInterval(refresh, 3000); return () => clearInterval(t) }, [refresh])

  const active = incidents.filter((i) => i.status !== 'Resolved')
  const stats = [
    ['Active emergencies', active.length, '#0ea5e9'], ['Critical incidents', active.filter((i) => i.tier === 'Critical').length, TIER.Critical],
    ['Available responders', responders.filter((r) => r.status === 'Available').length, '#7c3aed'], ['Resolved incidents', incidents.length - active.length, TIER.Resolved]]
  const picked = (i, msg) => { setSelectedId(i.id); setPage('Dashboard'); notify(msg); refresh() }
  const sos = () => api.create({ type: 'Other', description: 'SOS button pressed. Immediate help requested, details unknown.', people: 1, critical: true, address: 'SOS (simulated location)',
    lat: C[0] + (Math.random() - .5) * .03, lng: C[1] + (Math.random() - .5) * .03 }).then((i) => picked(i, 'SOS logged (simulated). No real service was contacted.')).catch((e) => notify(e.message, 'err'))
  const simulate = () => api.simulate().then((i) => picked(i, `Simulated emergency #${i.id} created`)).catch((e) => notify(e.message, 'err'))
  const reset = () => api.reset().then(() => { setSelectedId(null); refresh(); notify('Demo reset to the 3 sample emergencies') }).catch((e) => notify(e.message, 'err'))
  const dp = { onChange: refresh, onRoute: setRouteFrom, notify }
  const sel = incidents.find((i) => i.id === selectedId)

  return (
    <div className="flex min-h-screen flex-col bg-navy-800 text-slate-100 md:flex-row">
      <aside className="bg-navy-900 p-3 md:sticky md:top-0 md:h-screen md:w-56 md:p-4">
        <h1 className="mb-3 hidden font-display text-3xl font-bold tracking-wide md:block">Rescue<span className="text-red-500">Net</span></h1>
        <nav className="flex gap-1 overflow-x-auto md:flex-col">{NAV.map((n) => (
          <button key={n} onClick={() => setPage(n)} className={`whitespace-nowrap rounded-lg px-3 py-2 text-left text-sm font-medium transition ${page === n ? 'bg-white text-navy-800' : 'text-slate-300 hover:bg-navy-700'}`}>{n}</button>))}</nav>
        <p className="mt-6 hidden text-xs text-slate-400 md:block">{health.gemini ? `Gemini connected (${health.model})` : 'Gemini key not set: rule-based fallback active'}</p>
      </aside>

      <main className="min-w-0 flex-1 space-y-4 p-4">
        <div className="rounded-lg border border-yellow-400/40 bg-yellow-400/10 px-3 py-2 text-sm text-yellow-100">
          Prototype with simulated data. Not a replacement for official emergency services. In a real emergency call 112 or your local number.
        </div>
        {offline && <div className="rounded-lg bg-red-500/20 px-3 py-2 text-sm">Cannot reach the backend. Start it with <code>python app.py</code> in the backend folder.</div>}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-4xl font-semibold">{page}</h2>
          <div className="flex flex-wrap gap-2">
            <button className="btn bg-white/10 text-white hover:bg-white/20" onClick={simulate}>Simulate emergency</button>
            <button className="btn bg-white/10 text-white hover:bg-white/20" onClick={reset}>Reset demo</button>
            <button className="btn btn-red sos px-6 text-base" onClick={sos}>SOS</button>
          </div>
        </div>

        {page === 'Dashboard' && <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{stats.map(([l, v, c]) => (
            <div key={l} className="panel" style={{ borderTop: `4px solid ${c}` }}>
              <div className="font-display text-5xl font-semibold" style={{ color: c }}>{v}</div><div className="text-sm text-slate-600">{l}</div></div>))}</div>
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="panel h-[460px] !p-2 lg:col-span-2"><MapView incidents={incidents} responders={responders} selectedId={selectedId} onSelect={setSelectedId} routeFrom={routeFrom} /></div>
            <div className="panel h-[460px] overflow-y-auto"><h3 className="mb-2 font-semibold">Live incident queue</h3>
              <Queue items={incidents} selectedId={selectedId} onSelect={setSelectedId} empty="No incidents. Report one or simulate an emergency." /></div>
          </div>
          <div className="panel"><Detail inc={sel} {...dp} /></div>
          <details className="panel text-sm"><summary className="cursor-pointer font-semibold">Demo walkthrough</summary>
            <ol className="mt-2 list-decimal space-y-1 pl-5">
              <li>Open Report Emergency, click "Fill with demo report", then "Analyze with AI" to see the Gemini classification.</li>
              <li>Submit. The incident appears on the map with a calculated priority.</li>
              <li>Open it and click "Confirm trapped victim". The score jumps and it moves up the queue.</li>
              <li>Assign the recommended responder and watch the route on the map.</li>
              <li>Click "Mark resolved". "Reset demo" restores the three samples.</li></ol></details>
        </>}

        {page === 'Report Emergency' && <Report notify={notify} onDone={(i) => picked(i, `Incident #${i.id} reported. Priority ${i.score}.`)} />}
        {page === 'Incidents' && <IncidentsPage incidents={incidents} selectedId={selectedId} setSelectedId={setSelectedId} {...dp} />}

        {page === 'Responders' && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b text-slate-500"><th className="py-2">Unit</th><th>Type</th><th>Status</th><th>Incident</th></tr></thead>
              <tbody>{responders.map((r) => (<tr key={r.id} className="border-b last:border-0"><td className="py-2 font-medium">{r.name} <Pill c="#6d28d9">Simulated</Pill></td><td>{r.kind}</td>
                <td><Pill c={r.status === 'Available' ? '#15803d' : '#c2410c'}>{r.status}</Pill></td>
                <td>{r.incident_id ? <button className="text-sky-700 underline" onClick={() => { setSelectedId(r.incident_id); setPage('Dashboard') }}>#{r.incident_id}</button> : 'None'}</td></tr>))}</tbody></table></div>
            <div className="panel h-96 !p-2"><MapView responders={responders} /></div>
          </div>)}

        {page === 'Settings' && (
          <div className="panel max-w-2xl space-y-3 text-sm">
            <p><b>AI:</b> {health.gemini ? `Gemini is configured (${health.model}).` : 'No GEMINI_API_KEY found, so the rule-based classifier is used.'} If Gemini fails, reporting continues with the rule-based classifier.</p>
            <p><b>Data:</b> All incidents and responders are simulated and stored in a local SQLite file.</p>
            <p><b>Prototype notice:</b> RescueNet does not contact real emergency services.</p>
            <button className="btn btn-primary" onClick={reset}>Reset demo data</button>
          </div>)}
      </main>

      {toast && <div role="status" className={`fixed bottom-4 right-4 z-[1000] max-w-sm rounded-lg px-4 py-3 text-sm font-medium shadow-lg ${toast.kind === 'err' ? 'bg-red-600 text-white' : 'bg-white text-slate-900'}`}>{toast.msg}</div>}
    </div>
  )
}
