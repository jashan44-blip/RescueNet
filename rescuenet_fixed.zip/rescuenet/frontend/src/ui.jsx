export const TIER = { Critical: '#ef4444', High: '#f97316', Medium: '#eab308', Low: '#60a5fa', Resolved: '#22c55e' }
const INK = { Critical: '#b91c1c', High: '#c2410c', Medium: '#a16207', Low: '#1d4ed8', Resolved: '#15803d' }
const key = (i) => (i.status === 'Resolved' ? 'Resolved' : i.tier)
export const tierColor = (i) => TIER[key(i)]
export const inkOf = (i) => INK[key(i)]
export const ago = (ts) => {
  const m = Math.max(0, Math.round((Date.now() / 1000 - ts) / 60))
  return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : `${Math.floor(m / 60)} h ago`
}
export const Pill = ({ c, children }) => (
  <span className="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold" style={{ background: c + '1f', color: c }}>{children}</span>
)
export function Gauge({ score, color, size = 88 }) {
  const r = size / 2 - 7, c = 2 * Math.PI * r
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} role="img" aria-label={`Priority score ${score} of 100`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#e2e8f0" strokeWidth="7" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth="7" fill="none" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - score / 100)} style={{ transition: 'stroke-dashoffset .8s ease, stroke .4s' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center font-display text-4xl font-semibold" style={{ color }}>{score}</div>
    </div>
  )
}
