const BASE = import.meta.env.VITE_API_URL || '/api'
async function req(path, method = 'GET', body) {
  const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
  const j = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(j.error || r.statusText)
  return j
}
export const api = {
  health: () => req('/health'),
  incidents: () => req('/incidents'),
  responders: () => req('/responders'),
  create: (b) => req('/incidents', 'POST', b),
  simulate: () => req('/incidents/simulate', 'POST'),
  patch: (id, b) => req(`/incidents/${id}`, 'PATCH', b),
  recommend: (id) => req(`/incidents/${id}/recommend`),
  assign: (id, responder_id) => req(`/incidents/${id}/assign`, 'POST', { responder_id }),
  classify: (b) => req('/classify', 'POST', b),
  reset: () => req('/demo/reset', 'POST'),
}
