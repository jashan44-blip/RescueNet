import { useEffect, useState } from 'react'
import { api } from './api'
import { Gauge, Pill, tierColor, inkOf, ago } from './ui'

const AI_LABEL = { gemini: 'Gemini analysis', rules: 'Rule-based fallback (Gemini unavailable or pending)', seed: 'Preloaded sample data' }

export default function Detail({ inc, onChange, onRoute, notify }) {
  const [recs, setRecs] = useState([])
  const [assigned, setAssigned] = useState(null)
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!inc || inc.status === 'Resolved') { setRecs([]); setAssigned(null); onRoute(null); return }
    api.recommend(inc.id).then((r) => {
      setRecs(r.recommendations); setAssigned(r.assigned)
      const a = r.assigned || r.recommendations[0]
      onRoute(a ? [a.lat, a.lng] : null)
    }).catch(() => {})
  }, [inc?.id, inc?.status, inc?.responder_id])

  if (!inc) return <p className="p-8 text-center text-slate-500">Select an incident on the map or in the queue to see details and assign a responder.</p>
  const col = tierColor(inc), done = inc.status === 'Resolved'
  const act = async (fn) => { setBusy(true); try { await fn(); await onChange() } catch (e) { notify(e.message, 'err') } setBusy(false) }
  const patch = (body, msg) => act(async () => { await api.patch(inc.id, body); msg && notify(msg) })

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <Gauge score={inc.score} color={col} />
          <div className="min-w-0">
            <h3 className="font-display text-2xl font-semibold">#{inc.id} {inc.type}</h3>
            <div className="mt-1 flex flex-wrap gap-1.5">
              <Pill c={inkOf(inc)}>{done ? 'Resolved' : inc.tier + ' priority'}</Pill><Pill c="#475569">{inc.status}</Pill>
              {inc.trapped && <Pill c="#b91c1c">Someone trapped</Pill>}{inc.simulated && <Pill c="#6d28d9">Simulated</Pill>}
            </div>
            <p className="mt-1 text-xs text-slate-500">Reported {ago(inc.created_at)}{inc.address ? `, ${inc.address}` : ''}</p>
          </div>
        </div>
        <p className="whitespace-pre-line rounded-lg bg-slate-50 p-3 text-sm">{inc.description}</p>

        <div className="rounded-lg border border-sky-200 bg-sky-50 p-3 text-sm">
          <p className="font-semibold text-sky-900">{AI_LABEL[inc.ai_source] || 'Awaiting AI'}</p>
          <p className="mt-1 text-slate-700">Suggested action: {inc.ai_action}</p>
          <p className="mt-1 text-xs text-slate-500">Information confidence {Math.round(inc.confidence * 100)}%. AI suggestions support, and never override, the responder's decision.</p>
        </div>

        <div className="grid grid-cols-3 gap-3 text-sm">
          <div><span className="mb-1 block font-medium">People affected</span>
            <div className="flex items-center gap-2">
              <button className="btn btn-ghost px-2.5" disabled={done || busy || inc.people < 1} aria-label="Decrease" onClick={() => patch({ people: inc.people - 1 })}>-</button>
              <b className="w-6 text-center">{inc.people}</b>
              <button className="btn btn-ghost px-2.5" disabled={done || busy} aria-label="Increase" onClick={() => patch({ people: inc.people + 1 })}>+</button></div></div>
          <label><span className="mb-1 block font-medium">Trapped</span>
            <input type="checkbox" className="h-5 w-5" checked={inc.trapped} disabled={done || busy} onChange={(e) => patch({ trapped: e.target.checked })} /></label>
          <label><span className="mb-1 block font-medium">Severity</span>
            <select className="input" value={inc.severity} disabled={done || busy} onChange={(e) => patch({ severity: e.target.value })}>
              {['Low', 'Medium', 'High', 'Critical'].map((s) => <option key={s}>{s}</option>)}</select></label>
        </div>
        {inc.severity_locked && <p className="text-xs text-slate-500">Severity set by a responder. AI will not change it.</p>}

        {!done && (
          <div className="space-y-2">
            <label className="block text-sm font-medium" htmlFor="note">Add new information</label>
            <textarea id="note" className="input" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Two people are pinned inside and the driver is not responding." />
            <div className="flex flex-wrap gap-2">
              <button className="btn btn-primary" disabled={busy || !note.trim()} onClick={() => { patch({ note }, 'Update added, priority recalculated'); setNote('') }}>Send update</button>
              <button className="btn btn-red" disabled={busy} onClick={() => { patch({ trapped: true, note: note.trim() || 'New information: a victim is confirmed trapped and cannot get out unaided.' }, 'Trapped victim confirmed'); setNote('') }}>Confirm trapped victim</button>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <h4 className="mb-2 font-semibold">Responder assignment <span className="text-xs font-normal text-slate-500">(simulated units)</span></h4>
          {done ? <p className="text-sm text-slate-500">Incident resolved. Responder released.</p> : assigned ? (
            <div className="rounded-lg border border-emerald-300 bg-emerald-50 p-3 text-sm">
              <b>{assigned.name}</b> is assigned. {assigned.distance_km} km away, about {assigned.eta_min} min. Route is drawn on the map.
            </div>
          ) : recs.length ? (
            <ul className="space-y-2">{recs.map((r, n) => (
              <li key={r.id} className="flex items-center gap-3 rounded-lg border border-slate-200 p-3 text-sm">
                <div className="flex-1"><b>{r.name}</b> <span className="text-slate-500">({r.kind}, simulated)</span>
                  <p className="text-xs text-slate-500">{r.distance_km} km, about {r.eta_min} min, {r.match ? 'matches this emergency type' : 'different specialty'}{n === 0 ? ', recommended' : ''}</p></div>
                <button className="btn btn-primary" disabled={busy} onClick={() => act(async () => { await api.assign(inc.id, r.id); notify(`${r.name} assigned (simulated)`) })}>Assign</button>
              </li>))}</ul>
          ) : <p className="text-sm text-slate-500">No responders are available right now.</p>}
        </div>

        {!done && (
          <div className="flex flex-wrap gap-2">
            {inc.status === 'Assigned' && <button className="btn btn-ghost" disabled={busy} onClick={() => patch({ status: 'In progress' }, 'Marked in progress')}>Mark in progress</button>}
            <button className="btn bg-emerald-600 text-white hover:bg-emerald-700" disabled={busy} onClick={() => patch({ status: 'Resolved' }, `Incident #${inc.id} resolved`)}>Mark resolved</button>
          </div>
        )}

        <div>
          <h4 className="mb-2 font-semibold">Timeline</h4>
          <ol className="space-y-2 border-l-2 border-slate-200 pl-4 text-sm">
            {[...inc.updates].reverse().map((u, n) => (
              <li key={n}><span className="font-medium">{u.note}</span>
                <span className="block text-xs text-slate-500">{ago(u.ts)}, priority {u.score}</span></li>))}
          </ol>
        </div>
      </div>
    </div>
  )
}
