"""RescueNet backend: Flask + SQLite. PROTOTYPE with simulated data only."""
import os, re, json, math, random, sqlite3, threading, time
import requests
from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rescuenet.db")
KEY = os.getenv("GEMINI_API_KEY", "").strip()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
TYPES = ["Accident", "Fire", "Medical", "Flood", "Other"]
LEVELS = ["Low", "Medium", "High", "Critical"]
STATUSES = ["Reported", "Assigned", "In progress", "Resolved"]
SEV = dict(zip(LEVELS, [12, 28, 42, 55]))
KINDS = {"Fire": ["fire", "rescue"], "Medical": ["ambulance"], "Accident": ["ambulance", "police"],
         "Flood": ["rescue"], "Other": ["police", "ambulance"]}
CENTER = (30.4836, 76.5940)  # simulated city centre

app = Flask(__name__)
CORS(app)

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, description TEXT, address TEXT,
 lat REAL, lng REAL, people INTEGER, trapped INTEGER, critical INTEGER, severity TEXT, severity_locked INTEGER DEFAULT 0,
 confidence REAL, status TEXT DEFAULT 'Reported', responder_id INTEGER, ai_source TEXT, ai_action TEXT,
 simulated INTEGER DEFAULT 0, created_at REAL, resolved_at REAL);
CREATE TABLE IF NOT EXISTS responders(id INTEGER PRIMARY KEY, name TEXT, kind TEXT, lat REAL, lng REAL, status TEXT DEFAULT 'Available');
CREATE TABLE IF NOT EXISTS updates(id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id INTEGER, ts REAL, note TEXT, score INTEGER);
"""

RESPONDERS = [
    ("Engine 12", "fire", 30.4790, 76.6050), ("Engine 7", "fire", 30.4950, 76.5800),
    ("Medic 3", "ambulance", 30.4880, 76.5990), ("Medic 9", "ambulance", 30.4700, 76.5800),
    ("Medic 5", "ambulance", 30.5000, 76.5900), ("Patrol 21", "police", 30.4900, 76.6100),
    ("Rescue Team 2", "rescue", 30.4600, 76.6200)]

# (type, description, address, lat, lng, people, trapped, severity, confidence, minutes_ago, action)
SEEDS = [
    ("Accident", "Two-wheeler skidded at the bypass roundabout. Rider has a scraped arm, is conscious and walking.",
     "Bypass roundabout", 30.4905, 76.6010, 1, 0, "Low", .80, 6, "Send one patrol unit and basic first aid."),
    ("Fire", "Smoke and flames on the second floor of a shop building. One person at the window cannot get down the stairs.",
     "Ambala Road market", 30.4810, 76.5890, 1, 1, "High", .90, 12, "Dispatch fire engine and rescue crew; evacuate neighbours."),
    ("Accident", "Truck and car collided at the GT Road crossing. Two people injured, both conscious, one with a leg injury.",
     "GT Road crossing", 30.4720, 76.6120, 2, 0, "Medium", .85, 3, "Send ambulance and traffic patrol.")]

TEMPLATES = [
    ("Medical", "Elderly man collapsed in the market and is not responding. A bystander says he is breathing slowly."),
    ("Flood", "Water has entered homes near the drain. Three families are on the roof and the water is still rising."),
    ("Fire", "Kitchen fire in a restaurant. Staff are outside but two people may still be inside."),
    ("Accident", "Bus and motorcycle collision on the highway. Four people on the road, at least one bleeding heavily.")]


def db():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    return c


def seed(c):
    c.executescript("DROP TABLE IF EXISTS incidents; DROP TABLE IF EXISTS responders; DROP TABLE IF EXISTS updates;" + SCHEMA)
    for i, (n, k, la, ln) in enumerate(RESPONDERS, 1):
        c.execute("INSERT INTO responders VALUES(?,?,?,?,?,'Available')", (i, n, k, la, ln))
    for t, d, a, la, ln, p, tr, sv, cf, mins, act in SEEDS:
        cur = c.execute("""INSERT INTO incidents(type,description,address,lat,lng,people,trapped,critical,severity,confidence,
            ai_source,ai_action,simulated,created_at) VALUES(?,?,?,?,?,?,?,0,?,?,'seed',?,1,?)""",
                        (t, d, a, la, ln, p, tr, sv, cf, act, time.time() - mins * 60))
        add_update(c, cur.lastrowid, "Incident reported (preloaded sample)", priority(get_inc(c, cur.lastrowid))[0])


def init():
    with db() as c:
        c.executescript(SCHEMA)
        if not c.execute("SELECT 1 FROM responders").fetchone():
            seed(c)


# ---------- Priority engine ----------
def priority(i):
    end = i["resolved_at"] or time.time()
    mins = (end - i["created_at"]) / 60
    raw = SEV[i["severity"]] + min(i["people"], 8) * 3 + (25 if i["trapped"] or i["critical"] else 0) + min(mins / 3, 10)
    score = max(0, min(100, round(raw * (0.8 + 0.2 * i["confidence"]))))
    tier = "Critical" if score >= 75 else "High" if score >= 55 else "Medium" if score >= 30 else "Low"
    return score, tier


# ---------- AI classification (Gemini, validated) with rule-based fallback ----------
PROMPT = """You are a triage assistant in a PROTOTYPE emergency-dispatch demo. Read the report and reply with JSON only:
{"category": "Accident|Fire|Medical|Flood|Other", "severity": "Low|Medium|High|Critical", "people_affected": <integer>,
"trapped": <true|false>, "action": "<recommended response action, max 25 words>", "confidence": <0..1 how complete the report is>}
The reporter selected type: %s.
Report: %s"""


def clean_ai(d):
    cat, sev = d.get("category"), d.get("severity")
    ppl = int(d.get("people_affected", d.get("people")))
    trapped, act = d.get("trapped"), str(d.get("action", "")).strip()[:240]
    if cat not in TYPES or sev not in LEVELS or not isinstance(trapped, bool) or not 0 <= ppl <= 500 or not act:
        raise ValueError("invalid AI output")
    conf = max(0.0, min(1.0, float(d.get("confidence", 0.6))))
    return dict(category=cat, severity=sev, people=ppl, trapped=trapped, action=act, confidence=conf)


def gemini(text, hint):
    if not KEY:
        return None
    try:
        r = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent",
                          params={"key": KEY}, timeout=12,
                          json={"contents": [{"parts": [{"text": PROMPT % (hint, text[:1500])}]}],
                                "generationConfig": {"temperature": 0.1, "responseMimeType": "application/json"}})
        r.raise_for_status()
        out = clean_ai(json.loads(r.json()["candidates"][0]["content"]["parts"][0]["text"]))
        out["source"] = "gemini"
        return out
    except Exception as e:  # network, quota, bad JSON, failed validation -> caller falls back
        app.logger.warning("Gemini unavailable: %s", e)
        return None


WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
ACTIONS = {"Fire": "Dispatch fire engine and rescue crew.", "Medical": "Send nearest ambulance.",
           "Accident": "Send ambulance and traffic patrol.", "Flood": "Send rescue team with boat.", "Other": "Send patrol to assess."}


def rule_classify(text, hint="Other"):
    t = text.lower()
    kw = {"Fire": ["fire", "smoke", "flame", "burning"], "Flood": ["flood", "water level", "submerged", "drown"],
          "Medical": ["heart", "unconscious", "not breathing", "collapsed", "seizure"],
          "Accident": ["accident", "crash", "collision", "overturned", "skid"]}
    cat = next((k for k, w in kw.items() if any(x in t for x in w)), hint if hint in TYPES else "Other")
    trapped = any(x in t for x in ["trapped", "stuck", "pinned", "cannot get out", "can't get out"])
    nums = [int(n) for n in re.findall(r"\b\d{1,2}\b", t)] + [v for k, v in WORDS.items() if re.search(rf"\b{k}\b", t)]
    if any(x in t for x in ["unconscious", "not breathing", "explosion", "not responding", "heavily"]): sev = "Critical"
    elif trapped or cat == "Fire": sev = "High"
    elif any(x in t for x in ["injur", "hurt", "bleeding", "pain"]): sev = "Medium"
    else: sev = "Low"
    return dict(category=cat, severity=sev, people=max(nums) if nums else 1, trapped=trapped,
                action=ACTIONS[cat], confidence=0.5, source="rules")


def classify(text, hint):
    return gemini(text, hint) or rule_classify(text, hint)


# ---------- helpers ----------
def get_inc(c, iid):
    return c.execute("SELECT * FROM incidents WHERE id=?", (iid,)).fetchone()


def add_update(c, iid, note, score):
    c.execute("INSERT INTO updates(incident_id,ts,note,score) VALUES(?,?,?,?)", (iid, time.time(), note, score))


def ser(c, r):
    d = dict(r)
    d["score"], d["tier"] = priority(d)
    for k in ("trapped", "critical", "severity_locked", "simulated"):
        d[k] = bool(d[k])
    d["updates"] = [dict(u) for u in c.execute("SELECT ts,note,score FROM updates WHERE incident_id=? ORDER BY id", (d["id"],))]
    rr = c.execute("SELECT name FROM responders WHERE id=?", (d["responder_id"],)).fetchone()
    d["responder_name"] = rr["name"] if rr else None
    return d


def floor_high(sev, trapped, critical):
    return LEVELS[max(LEVELS.index(sev), 2)] if (trapped or critical) else sev


def apply_ai(c, r, ai):
    """AI may raise or refine its own fields, but never overrides a responder's severity decision."""
    f = {"ai_source": ai["source"], "ai_action": ai["action"], "confidence": ai["confidence"],
         "people": max(r["people"], ai["people"]), "trapped": int(bool(r["trapped"] or ai["trapped"]))}
    if r["type"] == "Other": f["type"] = ai["category"]
    if not r["severity_locked"]: f["severity"] = floor_high(ai["severity"], f["trapped"], r["critical"])
    c.execute(f"UPDATE incidents SET {','.join(k + '=?' for k in f)} WHERE id=?", [*f.values(), r["id"]])
    new = {**dict(r), **f}
    if r["status"] != "Resolved" and (new["severity"] != r["severity"] or new["people"] != r["people"]):
        add_update(c, r["id"], f"AI re-assessed: {new['severity']} severity, {new['people']} affected", priority(new)[0])


def reclassify(iid):
    """Background job so AI latency never delays reporting."""
    try:
        with db() as c:
            r = get_inc(c, iid)
            ai = gemini(r["description"], r["type"]) if r else None
            if ai: apply_ai(c, r, ai)
    except Exception:
        app.logger.exception("reclassify failed")


def create_incident(d, simulated=False):
    desc = str(d.get("description", "")).strip()[:1000]
    if not desc: raise ValueError("Description is required")
    typ = d.get("type") if d.get("type") in TYPES else "Other"
    lat, lng = float(d.get("lat") or CENTER[0]), float(d.get("lng") or CENTER[1])
    ai = None
    if isinstance(d.get("ai"), dict):  # preview already produced by /api/classify; re-validate
        try:
            ai = clean_ai(d["ai"]); ai["source"] = "gemini" if d["ai"].get("source") == "gemini" else "rules"
        except Exception: ai = None
    pending = ai is None
    ai = ai or rule_classify(desc, typ)
    people = max(int(d.get("people") or 0), ai["people"])
    trapped, critical = bool(d.get("trapped")) or ai["trapped"], bool(d.get("critical"))
    sev = floor_high(ai["severity"], trapped, critical)
    with db() as c:
        cur = c.execute("""INSERT INTO incidents(type,description,address,lat,lng,people,trapped,critical,severity,confidence,
            ai_source,ai_action,simulated,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (typ if typ != "Other" else ai["category"], desc, str(d.get("address", ""))[:120], lat, lng, people,
                         int(trapped), int(critical), sev, ai["confidence"], ai["source"], ai["action"], int(simulated), time.time()))
        iid = cur.lastrowid
        add_update(c, iid, "Incident reported", priority(get_inc(c, iid))[0])
    if pending and KEY:
        threading.Thread(target=reclassify, args=(iid,), daemon=True).start()
    with db() as c:
        return ser(c, get_inc(c, iid))


def haversine(a, b, c, d):
    p = math.pi / 180
    h = math.sin((c - a) * p / 2) ** 2 + math.cos(a * p) * math.cos(c * p) * math.sin((d - b) * p / 2) ** 2
    return 12742 * math.asin(math.sqrt(h))


def err(msg, code=400):
    return jsonify(error=msg), code


# ---------- routes ----------
@app.get("/")
def home():
    return jsonify(service="RescueNet API", status="running", health="/api/health", note="Open the Vite frontend at http://localhost:5173")


@app.get("/api/health")
def health():
    return jsonify(gemini=bool(KEY), model=MODEL, prototype=True)


@app.post("/api/classify")
def classify_route():
    d = request.get_json(force=True) or {}
    text = str(d.get("text", "")).strip()
    if not text: return err("Enter a description first")
    return jsonify(classify(text, d.get("type", "Other")))


@app.get("/api/incidents")
def list_incidents():
    with db() as c:
        items = [ser(c, r) for r in c.execute("SELECT * FROM incidents")]
    items.sort(key=lambda i: (i["status"] == "Resolved", -i["score"]))
    return jsonify(items)


@app.post("/api/incidents")
def post_incident():
    try: return jsonify(create_incident(request.get_json(force=True) or {})), 201
    except (ValueError, TypeError) as e: return err(str(e))


@app.post("/api/incidents/simulate")
def simulate():
    t, desc = random.choice(TEMPLATES)
    return jsonify(create_incident({"type": t, "description": desc, "people": 1, "address": "Simulated location",
                                    "lat": CENTER[0] + random.uniform(-.02, .02), "lng": CENTER[1] + random.uniform(-.02, .02)}, True)), 201


@app.patch("/api/incidents/<int:iid>")
def patch_incident(iid):
    d = request.get_json(force=True) or {}
    with db() as c:
        r = get_inc(c, iid)
        if not r: return err("Not found", 404)
        f, notes = {}, []
        note = str(d.get("note", "")).strip()[:500]
        if "people" in d:
            f["people"] = max(0, min(500, int(d["people"]))); notes.append(f"People affected set to {f['people']}")
        if "trapped" in d:
            f["trapped"] = int(bool(d["trapped"])); notes.append("Trapped victim confirmed" if f["trapped"] else "Trapped status cleared")
        if d.get("severity") in LEVELS:
            f["severity"], f["severity_locked"] = d["severity"], 1; notes.append(f"Responder set severity to {d['severity']}")
        if d.get("status") in STATUSES and d["status"] != r["status"]:
            f["status"] = d["status"]; notes.append(f"Status: {d['status']}")
            if d["status"] == "Resolved":
                f["resolved_at"] = time.time()
                if r["responder_id"]: c.execute("UPDATE responders SET status='Available' WHERE id=?", (r["responder_id"],))
        if note:
            f["description"] = r["description"] + "\n[Update] " + note
            f["confidence"] = min(1.0, r["confidence"] + 0.1); notes.append(note)
        if f:
            c.execute(f"UPDATE incidents SET {','.join(k + '=?' for k in f)} WHERE id=?", [*f.values(), iid])
            add_update(c, iid, "; ".join(notes), priority({**dict(r), **f})[0])
        out = ser(c, get_inc(c, iid))
    if note and not r["severity_locked"]:
        threading.Thread(target=reclassify, args=(iid,), daemon=True).start()
    return jsonify(out)


@app.get("/api/responders")
def responders():
    with db() as c:
        rs = [dict(r, simulated=True) for r in c.execute("SELECT * FROM responders")]
        for r in rs:
            x = c.execute("SELECT id FROM incidents WHERE responder_id=? AND status!='Resolved'", (r["id"],)).fetchone()
            r["incident_id"] = x["id"] if x else None
    return jsonify(rs)


@app.get("/api/incidents/<int:iid>/recommend")
def recommend(iid):
    with db() as c:
        i = get_inc(c, iid)
        if not i: return err("Not found", 404)
        rs = [dict(r, simulated=True) for r in c.execute("SELECT * FROM responders")]
    for r in rs:
        r["distance_km"] = round(haversine(r["lat"], r["lng"], i["lat"], i["lng"]), 2)
        r["eta_min"] = max(1, round(r["distance_km"] / 35 * 60))  # assumes ~35 km/h
        r["match"] = r["kind"] in KINDS[i["type"]]
    avail = sorted([r for r in rs if r["status"] == "Available"], key=lambda r: (not r["match"], r["distance_km"]))
    return jsonify(assigned=next((r for r in rs if r["id"] == i["responder_id"]), None), recommendations=avail[:3])


@app.post("/api/incidents/<int:iid>/assign")
def assign(iid):
    rid = (request.get_json(force=True) or {}).get("responder_id")
    with db() as c:
        i, r = get_inc(c, iid), c.execute("SELECT * FROM responders WHERE id=?", (rid,)).fetchone()
        if not i or not r: return err("Not found", 404)
        if i["status"] == "Resolved": return err("Incident already resolved")
        if r["status"] != "Available": return err(f"{r['name']} is not available")
        if i["responder_id"]: c.execute("UPDATE responders SET status='Available' WHERE id=?", (i["responder_id"],))
        c.execute("UPDATE responders SET status='Assigned' WHERE id=?", (rid,))
        c.execute("UPDATE incidents SET responder_id=?, status='Assigned' WHERE id=?", (rid, iid))
        add_update(c, iid, f"Assigned {r['name']} (simulated responder)", priority(i)[0])
        return jsonify(ser(c, get_inc(c, iid)))


@app.post("/api/demo/reset")
def reset():
    with db() as c: seed(c)
    return jsonify(ok=True)


init()
if __name__ == "__main__":
    app.run(port=int(os.getenv("PORT", 5000)), debug=False)
